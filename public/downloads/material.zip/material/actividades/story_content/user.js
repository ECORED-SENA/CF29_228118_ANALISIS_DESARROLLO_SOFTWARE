function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5iqXVvcPrdO":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

